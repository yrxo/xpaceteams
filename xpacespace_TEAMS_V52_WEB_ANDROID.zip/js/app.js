
(function(){
'use strict';

const XP = window.XP_ROLES || {};
const CEO_EMAIL = String(XP.CEO || 'r4908994@gmail.com').trim().toLowerCase();
const CMO_EMAIL = String(XP.CMO || 'sarthakxxu@gmail.com').trim().toLowerCase();

let auth = null, db = null, storage = null, currentUser = null, currentProfile = null, countdownTimer = null;
function exposeRuntime(){ window.xpAuth=auth; window.db=db; window.storage=storage; window.currentUser=currentUser; window.currentProfile=currentProfile; }

const $ = id => document.getElementById(id);
const cleanEmail = e => String(e || '').trim().toLowerCase();

function initFirebase(){
  if(!window.firebase || !window.XP_FIREBASE_CONFIG) return false;
  if(!firebase.apps.length) firebase.initializeApp(window.XP_FIREBASE_CONFIG);
  auth = firebase.auth();
  db = firebase.firestore();
  storage = firebase.storage();
  exposeRuntime();
  return true;
}

function friendly(e){
  return e && e.message ? e.message.replace(/^Firebase:\s*/,'') : String(e);
}

function notice(message, type=''){
  const el = $('authNotice');
  if(!el) return;
  el.textContent = message;
  el.className = 'notice show ' + type;
}

function toast(message){
  const el = $('toast');
  if(!el) return;
  el.textContent = message;
  el.classList.add('show');
  setTimeout(()=>el.classList.remove('show'), 3200);
}

function esc(s){
  return String(s ?? '').replace(/[&<>"']/g, m => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[m]));
}

/* ---------- public auth ---------- */
async function signup(e){
  e.preventDefault();
  if(!initFirebase()) return notice('Firebase configuration is unavailable.','error');

  let cred = null;
  let profileCreated = false;
  let usernameCreated = false;
  let username = '';
  let profileRef = null;
  let usernameRef = null;

  try{
    const name = $('signupName').value.trim();
    const emailInput = $('signupEmail').value.trim();
    const password = $('signupPassword').value;
    username = $('signupUsername').value.trim().toLowerCase();
    const requestedXpsId = $('signupXps').value.trim().toUpperCase();

    if(name.length < 2) throw Error('Enter your name.');
    if(!/^[a-z0-9_.-]{3,24}$/.test(username))
      throw Error('Username must be 3–24 characters.');

    // 1) Create Firebase Auth account first.
    cred = await auth.createUserWithEmailAndPassword(emailInput, password);
    const user = cred.user;
    const email = cleanEmail(user.email);
    const role = email === CEO_EMAIL ? 'ceo' : email === CMO_EMAIL ? 'admin' : 'member';
    const isPrivileged = role !== 'member';

    // 2) Create the actual crew profile FIRST.
    // This is the critical fix: profile creation no longer depends on
    // the usernames index being writable.
    profileRef = db.collection('users').doc(user.uid);
    await profileRef.set({
      uid: user.uid,
      name,
      username,
      email,
      requestedXpsId,
      xpsId: isPrivileged ? (role === 'ceo' ? 'XPS-CEO' : 'XPS-CMO') : null,
      role,
      designation: isPrivileged ? (role === 'ceo' ? 'CEO / God Admin' : 'CMO / Admin') : null,
      mobile: null,
      approvalStatus: isPrivileged ? 'approved' : 'pending',
      verified: isPrivileged,
      createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    profileCreated = true;

    // 3) Build the username index separately.
    // If this secondary index is blocked, DON'T destroy the valid login/profile.
    try{
      usernameRef = db.collection('usernames').doc(username);
      await usernameRef.create({
        uid: user.uid,
        username,
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });
      usernameCreated = true;
    }catch(indexErr){
      if(indexErr?.code === 'already-exists'){
        // A duplicate username must not leave a duplicate account.
        try{ await profileRef.delete(); }catch(_e){}
        try{ await user.delete(); }catch(_e){}
        return notice('That username is already in use. Choose another one.','error');
      }

      // Keep the authenticated account/profile alive. The user can still
      // log in; the workspace can repair/rebuild the username index later.
      console.error('[XP V49] username index write failed:', indexErr);
      return notice(
        'Crew profile created, but the username index could not be saved. You can still log in; contact the CEO/admin to repair the index.',
        'error'
      );
    }

    notice(
      isPrivileged
        ? 'Leadership account recognized. Opening TEAMS…'
        : 'Crew account created. CEO approval is pending.',
      'ok'
    );
    setTimeout(()=>location.href='workspace.html',650);

  }catch(err){
    console.error('[XP V49] signup failed:', err);

    // Only roll back the profile if the PROFILE operation itself failed.
    // This avoids deleting a valid account because of a secondary index issue.
    if(profileCreated && profileRef){
      // If we reached here after profile creation, keep the account alive.
      return notice('Your crew profile was created, but setup hit an unexpected error. Please log in again.','error');
    }

    try{ if(cred?.user) await cred.user.delete(); }catch(_e){}

    if(err?.code === 'permission-denied'){
      return notice(
        'Firebase blocked the /users profile write. Check that the published Firestore rules allow an authenticated user to create their own /users/{uid} document.',
        'error'
      );
    }

    if(err?.code === 'email-already-in-use')
      return notice('An account already exists with this email. Try Log in instead.','error');

    notice(friendly(err),'error');
  }
}
async function login(e){
  e.preventDefault();
  if(!initFirebase()) return notice('Firebase configuration is unavailable.','error');
  try{
    await auth.signInWithEmailAndPassword(
      $('loginEmail').value.trim(),
      $('loginPassword').value
    );
    location.href='workspace.html';
  }catch(err){
    notice(friendly(err),'error');
  }
}

function bindIndex(){
  $('loginForm')?.addEventListener('submit',login);
  $('signupForm')?.addEventListener('submit',signup);
}

/* ---------- navigation ---------- */
function nav(){
  const closeDrawer=()=>{
    $('mobileDrawer')?.classList.remove('open');
    $('drawerBackdrop')?.classList.remove('open');
    $('hamburger')?.classList.remove('open');
    $('hamburger')?.setAttribute('aria-expanded','false');
    $('mobileDrawer')?.setAttribute('aria-hidden','true');
  };

  document.querySelectorAll('[data-view]').forEach(button=>{
    button.addEventListener('click',()=>{
      const v=button.dataset.view;
      const approval=String(currentProfile?.approvalStatus||'pending').toLowerCase();
      const privileged=isAdmin();
      const allowed=privileged || approval==='approved' || v==='home' || v==='profile';
      if(!allowed){
        document.querySelectorAll('.view').forEach(x=>x.classList.remove('active'));
        $('view-home')?.classList.add('active');
        document.querySelectorAll('[data-view]').forEach(x=>x.classList.toggle('active',x.dataset.view==='home'));
        $('viewTitle').textContent='HOME';
        toast('ACCESS PENDING — CEO approval required.');
        closeDrawer();
        window.scrollTo({top:0,behavior:'smooth'});
        return;
      }
      document.querySelectorAll('.view').forEach(x=>x.classList.remove('active'));
      $('view-'+v)?.classList.add('active');
      document.querySelectorAll('[data-view]').forEach(x=>x.classList.toggle('active',x.dataset.view===v));
      $('viewTitle').textContent=v.toUpperCase();
      closeDrawer();
      window.scrollTo({top:0,behavior:'smooth'});
    });
  });

  const toggleDrawer=()=>{
    const open=!$('mobileDrawer')?.classList.contains('open');
    $('mobileDrawer')?.classList.toggle('open',open);
    $('drawerBackdrop')?.classList.toggle('open',open);
    $('hamburger')?.classList.toggle('open',open);
    $('hamburger')?.setAttribute('aria-expanded',String(open));
    $('mobileDrawer')?.setAttribute('aria-hidden',String(!open));
  };
  $('hamburger')?.addEventListener('click',toggleDrawer);
  $('drawerClose')?.addEventListener('click',closeDrawer);
  $('drawerBackdrop')?.addEventListener('click',closeDrawer);
  document.addEventListener('keydown',e=>{if(e.key==='Escape') closeDrawer();});
}

/* ---------- identity / roles ---------- */
function roleForEmail(email){
  const e=cleanEmail(email);
  if(e===CEO_EMAIL) return 'ceo';
  if(e===CMO_EMAIL) return 'admin';
  return 'member';
}

function leadershipFor(profile, email){
  const emailRole = roleForEmail(email);
  if(emailRole !== 'member') return emailRole;
  return String(profile?.role || 'member').toLowerCase();
}

function render(profile){
  const email=cleanEmail(currentUser?.email);
  const role=leadershipFor(profile,email);
  const isCEO=role==='ceo' || email===CEO_EMAIL;
  const isCMO=role==='admin' || email===CMO_EMAIL;

  const name=profile?.name || currentUser?.displayName || 'Crew Member';

  $('topName').textContent=name;
  $('topAvatar').textContent=name.charAt(0).toUpperCase();
  $('cardName').textContent=name;

  const roleLabel = isCEO ? 'CEO / GOD ADMIN' : isCMO ? 'CMO / ADMIN' : 'CREW MEMBER';
  const approval = profile?.approvalStatus || (isCEO||isCMO ? 'approved' : 'pending');

  $('cardRole').textContent=roleLabel+' · '+approval.toUpperCase();
  $('cardXps').textContent=profile?.xpsId || profile?.requestedXpsId || 'XPS-PENDING';

  const approvalEl=$('cardApproval');
  approvalEl.textContent=isCEO ? 'GOD ADMIN' : isCMO ? 'ADMIN / CMO' : approval.toUpperCase()+' · CEO APPROVAL';
  approvalEl.className='approval '+(isCEO||isCMO?'approved':approval);

  $('statusTitle').textContent=
    isCEO ? 'God Admin access active' :
    isCMO ? 'CMO Admin access active' :
    approval==='approved' ? 'Crew access approved' :
    approval==='rejected' ? 'Access rejected' :
    'Pending CEO approval';

  $('statusDesc').textContent=
    isCEO ? 'Full organization control is enabled for the CEO account.' :
    isCMO ? 'Operational administration is enabled. CEO-only controls remain locked.' :
    approval==='approved' ? 'You are cleared for verified team operations.' :
    approval==='rejected' ? 'This account was rejected by the CEO.' :
    'The CEO must approve this account within 24 hours.';

  $('adminNav').style.display=(isCEO||isCMO)?'block':'none';
  if($('drawerAdminNav')) $('drawerAdminNav').style.display=(isCEO||isCMO)?'grid':'none';
  $('statCrew').textContent=approval==='approved'?'VERIFIED':'PENDING';

  viewedProfileUid=currentUser?.uid;
  renderProfile(profile);
    countdown(profile?.createdAt,approval,isCEO||isCMO);

  if(isCEO || isCMO) loadAdmin();
  if(approval==='approved' || isCEO || isCMO){ loadCrew(); loadProjects(); loadTasks(); loadGraze(); loadFiles(); }
  if(isCEO || isCMO){ $('assignTaskBtn')?.style && ($('assignTaskBtn').style.display='inline-flex'); }
}

function countdown(ts,status,privileged){
  clearInterval(countdownTimer);
  const el=$('countdown');

  if(privileged || status!=='pending'){
    el.textContent=privileged ? 'CLEARED' : status==='approved' ? 'CLEARED' : '—';
    return;
  }

  if(!ts){
    el.textContent='24:00:00';
    return;
  }

  const start=ts.toDate ? ts.toDate().getTime() : new Date(ts).getTime();
  const end=start+86400000;

  const tick=()=>{
    let d=end-Date.now();
    if(d<=0){
      el.textContent='EXPIRED';
      clearInterval(countdownTimer);
      return;
    }
    const h=Math.floor(d/36e5);
    const m=Math.floor((d%36e5)/6e4);
    const s=Math.floor((d%6e4)/1e3);
    el.textContent=[h,m,s].map(x=>String(x).padStart(2,'0')).join(':');
  };

  tick();
  countdownTimer=setInterval(tick,1000);
}

/* ---------- first-time / new-device profile gate ---------- */
async function ensureProfileGate(profile){
  // Pending/rejected users must never be blocked by onboarding. Their workspace
  // remains visible, but operational sections are locked until approval.
  const approval = profile?.approvalStatus || 'pending';
  const privileged = isAdmin();
  if(!privileged && approval !== 'approved'){ closeOnboarding(); return; }
  const needs = !profile || !profile.designation || !profile.mobile;

  if(!needs){
    closeOnboarding();
    return;
  }

  $('onboardName').value=profile?.name || currentUser?.displayName || '';
  $('onboardEmail').value=currentUser?.email || profile?.email || '';

  $('onboardingDesignation').value=profile?.designation || '';
  $('onboardingMobile').value=profile?.mobile || '';

  $('onboarding').classList.add('open');
}

async function saveOnboarding(e){
  e.preventDefault();

  const designation=$('onboardingDesignation').value.trim();
  const mobile=$('onboardingMobile').value.trim();

  if(designation.length<2) return toast('Enter your designation.');
  if(!/^[0-9+() .-]{7,20}$/.test(mobile)) return toast('Enter a valid mobile number.');

  try{
    await db.collection('users').doc(currentUser.uid).set({
      designation,
      mobile,
      updatedAt:firebase.firestore.FieldValue.serverTimestamp()
    },{merge:true});

    closeOnboarding();
    toast('Crew profile updated.');
  }catch(err){
    toast(friendly(err));
  }
}

function closeOnboarding(){
  $('onboarding')?.classList.remove('open');
}

/* ---------- admin ---------- */
async function createUserNotification(uid,title,body,icon='✦',link=''){
  try{ if(!isAdmin()) return; await db.collection('notifications').add({uid,title,body,icon,link,read:false,createdAt:firebase.firestore.FieldValue.serverTimestamp(),createdBy:currentUser.uid}); }catch(e){ console.warn('notification write failed',e); }
}

async function approveUser(uid){
  if(!isCEO()) return toast('Only the CEO can approve accounts.');
  const id=prompt('Assign final XPS ID','XPS-'+Math.floor(100+Math.random()*900)); if(!id)return;
  const x=id.trim().toUpperCase();
  try{const taken=await db.collection('users').where('xpsId','==',x).limit(1).get();if(!taken.empty)return toast('XPS ID already assigned.');await db.collection('users').doc(uid).update({xpsId:x,approvalStatus:'approved',verified:true,approvedBy:CEO_EMAIL,approvedAt:firebase.firestore.FieldValue.serverTimestamp(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()});await createUserNotification(uid,'Crew account approved','Your XPACE OS access is now active.','✓','view:home');toast('Crew approved.');loadAdmin();}catch(e){toast(friendly(e));}
}
async function rejectUser(uid){
  if(!isCEO())return toast('Only the CEO can reject accounts.'); if(!confirm('Reject this account?'))return;
  try{await db.collection('users').doc(uid).update({approvalStatus:'rejected',verified:false,rejectedBy:CEO_EMAIL,rejectedAt:firebase.firestore.FieldValue.serverTimestamp()});await createUserNotification(uid,'Account update','Your crew account was rejected by the CEO.','!','view:home');toast('Account rejected.');loadAdmin();}catch(e){toast(friendly(e));}
}

async function loadAdmin(){
  const table=$('pendingTable');
  if(!table || !db) return;

  const email=cleanEmail(currentUser?.email);
  const profileRole=leadershipFor(currentProfile,email);
  const isCEO=email===CEO_EMAIL || profileRole==='ceo';
  const isCMO=email===CMO_EMAIL || profileRole==='admin';

  if(!isCEO && !isCMO){
    table.innerHTML='<tr><td colspan="5">Admin access unavailable.</td></tr>';
    return;
  }

  const q=await db.collection('users').where('approvalStatus','==','pending').limit(100).get();
  table.innerHTML='';

  if(q.empty){
    table.innerHTML='<tr><td colspan="5">No pending accounts.</td></tr>';
    return;
  }

  q.forEach(doc=>{
    const p=doc.data();
    const created=p.createdAt?.toDate?.() || new Date();
    const age=Math.max(0,Math.floor((Date.now()-created.getTime())/36e5));

    table.innerHTML += `
      <tr>
        <td><b>${esc(p.name)}</b><br><span class="sub">@${esc(p.username)}</span></td>
        <td>${esc(p.email)}</td>
        <td>${esc(p.requestedXpsId||'—')}</td>
        <td>${age}h</td>
        <td>
          ${isCEO
            ? `<button class="mini-btn" onclick="approveUser('${doc.id}')">APPROVE</button>
               <button class="mini-btn light" onclick="rejectUser('${doc.id}')">REJECT</button>`
            : '<span class="sub">CEO ONLY</span>'}
        </td>
      </tr>`;
  });
}

async function approveUser(uid){
  if(cleanEmail(currentUser?.email)!==CEO_EMAIL)
    return toast('Only the CEO can approve accounts.');

  const id=prompt('Assign final XPS ID','XPS-'+Math.floor(100+Math.random()*900));
  if(!id) return;

  const x=id.trim().toUpperCase();
  const taken=await db.collection('users').where('xpsId','==',x).limit(1).get();
  if(!taken.empty) return toast('XPS ID already assigned.');

  await db.collection('users').doc(uid).update({
    xpsId:x,
    approvalStatus:'approved',
    verified:true,
    approvedBy:CEO_EMAIL,
    approvedAt:firebase.firestore.FieldValue.serverTimestamp(),
    updatedAt:firebase.firestore.FieldValue.serverTimestamp()
  });

  toast('Crew approved.');
  loadAdmin();
}

async function rejectUser(uid){
  if(cleanEmail(currentUser?.email)!==CEO_EMAIL)
    return toast('Only the CEO can reject accounts.');

  if(!confirm('Reject this account?')) return;

  await db.collection('users').doc(uid).update({
    approvalStatus:'rejected',
    verified:false,
    rejectedBy:CEO_EMAIL,
    rejectedAt:firebase.firestore.FieldValue.serverTimestamp()
  });

  toast('Account rejected.');
  loadAdmin();
}

async function loadCrew(){
  const el=$('crewList');
  if(!el || !db) return;

  try{
    const q=await db.collection('users').where('verified','==',true).limit(50).get();
    el.innerHTML='';
    q.forEach(doc=>{
      const p=doc.data();
      el.innerHTML+=`
        <div class="activity-item">
          <span><b>${esc(p.name)}</b> · @${esc(p.username||'crew')}</span>
          <small>${esc(p.xpsId||'XPS')}</small>
        </div>`;
    });
    if(q.empty) el.innerHTML='<div class="activity-item"><span>No verified crew yet.</span></div>';
  }catch(err){
    el.innerHTML='<div class="activity-item"><span>Unable to load crew.</span></div>';
  }
}


/* ---------- XPACE SEARCH / PROFILES ---------- */
let activeSearchFilter='all';
let viewedProfileUid=null;

function initials(name){
  return String(name||'X').trim().split(/\s+/).slice(0,2).map(x=>x[0]).join('').toUpperCase()||'X';
}
function profileAvatarMarkup(p, cls=''){
  const url=p?.avatarUrl;
  return url ? `<img class="${cls}" src="${esc(url)}" alt="${esc(p?.name||'Crew')}" loading="lazy">` : `<div class="${cls||'avatar'} avatar-fallback">${esc(initials(p?.name))}</div>`;
}

async function searchXpace(term){
  const out=$('searchResults'), title=$('searchResultTitle');
  if(!out||!db||!currentUser) return;
  term=String(term||'').trim().toLowerCase();
  if(!term){ out.innerHTML='<div class="empty-state">Type something above to search the crew network.</div>'; title.textContent='Search XPACE'; return; }
  title.textContent=`Results for “${term}”`;
  out.innerHTML='<div class="empty-state">Searching XPACE…</div>';
  try{
    const filter=activeSearchFilter;
    const jobs=[];
    if(filter==='all'||filter==='people') jobs.push(db.collection('users').where('verified','==',true).limit(100).get());
    if(filter==='all'||filter==='projects') jobs.push(db.collection('projects').where('status','==','approved').limit(100).get());
    if(filter==='all'||filter==='graze') jobs.push(db.collection('graze').where('status','==','approved').limit(100).get());
    const results=[];
    const qs=await Promise.all(jobs);
    let i=0;
    if(filter==='all'||filter==='people'){
      qs[i++].forEach(d=>{const x=d.data();const hay=[x.name,x.username,x.email,x.xpsId,x.designation,x.bio].join(' ').toLowerCase();if(hay.includes(term))results.push({type:'people',id:d.id,data:x});});
    }
    if(filter==='all'||filter==='projects'){
      qs[i++].forEach(d=>{const x=d.data();const hay=[x.name,x.description,x.ownerName,x.ownerUsername].join(' ').toLowerCase();if(hay.includes(term))results.push({type:'projects',id:d.id,data:x});});
    }
    if(filter==='all'||filter==='graze'){
      qs[i++].forEach(d=>{const x=d.data();const hay=[x.caption,x.title,x.location,x.ownerName,x.ownerUsername].join(' ').toLowerCase();if(hay.includes(term))results.push({type:'graze',id:d.id,data:x});});
    }
    if(!results.length){out.innerHTML='<div class="empty-state">No matching records found.</div>';return;}
    out.innerHTML=results.slice(0,40).map(r=>{
      if(r.type==='people') return `<button class="search-result-card person-result" onclick="openProfile('${r.id}')">${profileAvatarMarkup(r.data,'search-avatar')}<span><b>${esc(r.data.name||'Crew Member')}</b><small>@${esc(r.data.username||'crew')} · ${esc(r.data.xpsId||'XPS')}</small><em>${esc(r.data.designation||'CREW MEMBER')}</em></span><strong>VIEW →</strong></button>`;
      if(r.type==='projects') return `<div class="search-result-card"><span class="search-icon">◇</span><span><b>${esc(r.data.name||'Project')}</b><small>@${esc(r.data.ownerUsername||'crew')} · PROJECT</small><em>${esc(r.data.description||'')}</em></span></div>`;
      return `<div class="search-result-card"><img class="search-graze" src="${esc(r.data.image?.url||'')}" alt=""><span><b>${esc(r.data.caption||r.data.title||'Night sky')}</b><small>@${esc(r.data.ownerUsername||'crew')} · GRAZE SPACE</small><em>${esc(r.data.location||'')}</em></span></div>`;
    }).join('');
  }catch(e){out.innerHTML=`<div class="empty-state">Search unavailable: ${esc(e.message||'permission error')}</div>`;}
}

async function openProfile(uid){
  if(!uid||!db) return;
  try{
    const snap=await db.collection('users').doc(uid).get();
    if(!snap.exists) return toast('Crew profile not found.');
    const p={uid:snap.id,...snap.data()};
    if(p.verified!==true && uid!==currentUser?.uid && !isAdmin()) return toast('That profile is not public.');
    viewedProfileUid=uid;
    renderProfile(p);
    document.querySelectorAll('.view').forEach(x=>x.classList.remove('active'));
    $('view-profile')?.classList.add('active');
    document.querySelectorAll('[data-view]').forEach(x=>x.classList.toggle('active',x.dataset.view==='profile'));
    $('viewTitle').textContent='PROFILE';
    window.scrollTo({top:0,behavior:'smooth'});
  }catch(e){toast(friendly(e));}
}

async function renderProfile(p){
  if(!p) return;
  $('profileName').textContent=p.name||'Crew Member';
  $('profileUsername').textContent='@'+(p.username||'crew');
  $('profileBio').textContent=p.bio||'Building the next era of space innovation.';
  $('profileXps').textContent=p.xpsId||p.requestedXpsId||'XPS-PENDING';
  $('profileDesignation').textContent=(p.designation||'CREW MEMBER').toUpperCase();
  $('profileVerified').textContent=p.verified===true?'VERIFIED CREW':'PENDING';
  const av=$('profileAvatar');
  av.innerHTML=p.avatarUrl?`<img src="${esc(p.avatarUrl)}" alt="${esc(p.name||'Crew')}" loading="lazy">`:`<span>${esc(initials(p.name))}</span>`;
  try{
    const taskPromise=(p.uid===currentUser?.uid && p.verified===true || isAdmin())
      ? db.collection('tasks').where('assigneeUid','==',p.uid).where('status','==','completed').limit(100).get()
      : Promise.resolve({size:0,forEach:()=>{}});
    const projectPromise=(p.verified===true || isAdmin() || p.uid===currentUser?.uid)
      ? db.collection('projects').where('ownerUid','==',p.uid).where('status','==','approved').limit(50).get()
      : Promise.resolve({size:0,forEach:()=>{}});
    const [g,t,pr]=await Promise.all([
      db.collection('graze').where('ownerUid','==',p.uid).where('status','==','approved').limit(50).get(),
      taskPromise,
      projectPromise
    ]);
    $('profileGrazeCount').textContent=g.size;
    $('profileTaskCount').textContent=t.size;
    $('profileMissionCount').textContent=pr.size;
    renderProfileTab('graze',p,g,pr);
  }catch(e){$('profileContent').innerHTML='<div class="empty-state">Some profile activity is unavailable.</div>';}
}

async function renderProfileTab(tab,p,gSnap,prSnap){
  document.querySelectorAll('.profile-tab').forEach(b=>b.classList.toggle('active',b.dataset.profileTab===tab));
  const el=$('profileContent'); if(!el)return;
  if(tab==='graze'){
    let cards='';
    if(gSnap) gSnap.forEach(d=>{const x=d.data();cards+=`<article class="profile-photo"><img src="${esc(x.image?.url||'')}" alt="${esc(x.caption||'Night sky')}" loading="lazy"><div><b>${esc(x.caption||'Night sky')}</b><small>${esc(x.location||'')}</small></div></article>`;});
    el.innerHTML=cards?`<div class="profile-photo-grid">${cards}</div>`:'<div class="empty-state">No approved Graze observations yet.</div>';
    return;
  }
  if(tab==='projects'){
    let html=''; if(prSnap) prSnap.forEach(d=>{const x=d.data();html+=`<div class="activity-item"><span><b>${esc(x.name||'Project')}</b><small>${esc(x.description||'')}</small></span><small>APPROVED</small></div>`;});
    el.innerHTML=html||'<div class="empty-state">No public projects yet.</div>'; return;
  }
  el.innerHTML=`<div class="activity-item"><span><b>CREW PROFILE</b><small>Member since ${esc(p.createdAt?.toDate?.()?.toLocaleDateString?.()||'xpacespace')}</small></span><small>${esc(p.xpsId||'XPS-PENDING')}</small></div>`;
}

function openProfileEditor(){
  const p=currentProfile||{};
  openModal('EDIT CREW PROFILE',`<form class="form" id="profileEditForm">
    <div class="field"><label>NAME</label><input id="epName" maxlength="80" value="${esc(p.name||'')}"></div>
    <div class="field"><label>USERNAME</label><input value="@${esc(p.username||'crew')}" disabled></div>
    <div class="field"><label>DESIGNATION</label><input id="epDesignation" maxlength="80" value="${esc(p.designation||'')}"></div>
    <div class="field"><label>BIO</label><textarea id="epBio" rows="4" maxlength="240" placeholder="A short crew bio…">${esc(p.bio||'')}</textarea></div>
    <div class="field"><label>PROFILE PHOTO</label><input id="epAvatar" type="file" accept="image/*"></div>
    <button class="btn">SAVE PROFILE →</button></form>`);
  $('profileEditForm').onsubmit=async e=>{e.preventDefault();try{
    const patch={name:$('epName').value.trim(),designation:$('epDesignation').value.trim(),bio:$('epBio').value.trim(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()};
    const f=$('epAvatar').files[0]; if(f) patch.avatarUrl=(await uploadStorage(f,`profiles/${currentUser.uid}/${Date.now()}_${safeFile(f.name)}`)).url;
    await db.collection('users').doc(currentUser.uid).update(patch); currentProfile={...currentProfile,...patch}; if(patch.updatedAt) delete currentProfile.updatedAt;
    closeModal(); toast('Profile updated.'); renderProfile(currentProfile);
  }catch(err){toast(friendly(err));}};
}

function bindSearchProfile(){
  $('fileForm')?.addEventListener('submit',async e=>{e.preventDefault();try{const f=$('workspaceFile')?.files?.[0];if(!f)return toast('Choose a file first.');const data=await uploadStorage(f,`files/${currentUser.uid}/${Date.now()}_${safeFile(f.name)}`);await db.collection('files').add({ownerUid:currentUser.uid,ownerName:currentProfile?.name||'',ownerUsername:currentProfile?.username||'',description:'Workspace upload',file:data,status:'active',createdAt:firebase.firestore.FieldValue.serverTimestamp()});e.target.reset();toast('File uploaded.');loadFiles();if(isAdmin())loadAdmin();}catch(err){toast(friendly(err));}});
  $('searchBtn')?.addEventListener('click',()=>searchXpace($('globalSearch')?.value));
  $('globalSearch')?.addEventListener('keydown',e=>{if(e.key==='Enter')searchXpace(e.target.value);});
  document.querySelectorAll('.search-filter').forEach(b=>b.addEventListener('click',()=>{activeSearchFilter=b.dataset.searchFilter;document.querySelectorAll('.search-filter').forEach(x=>x.classList.toggle('active',x===b));if($('globalSearch')?.value)searchXpace($('globalSearch').value);}));
  document.querySelectorAll('.profile-tab').forEach(b=>b.addEventListener('click',async()=>{const uid=viewedProfileUid||currentUser?.uid;const snap=await db.collection('users').doc(uid).get();if(snap.exists){const p={uid:snap.id,...snap.data()};const [g,pr]=await Promise.all([db.collection('graze').where('ownerUid','==',uid).where('status','==','approved').limit(50).get(),db.collection('projects').where('ownerUid','==',uid).where('status','==','approved').limit(50).get()]);renderProfileTab(b.dataset.profileTab,p,g,pr);}}));
}

/* ---------- modal actions ---------- */
function openModal(title,body){
  $('modalTitle').textContent=title;
  $('modalBody').innerHTML=body;
  $('modal').classList.add('open');
}
function closeModal(){ $('modal').classList.remove('open'); }

function isCEO(){ return cleanEmail(currentUser?.email)===CEO_EMAIL || String(currentProfile?.role||'').toLowerCase()==='ceo'; }
function isAdmin(){ return isCEO() || cleanEmail(currentUser?.email)===CMO_EMAIL || String(currentProfile?.role||'').toLowerCase()==='admin'; }

function openProjectModal(){
  openModal('NEW PROJECT',`
    <form class="form" id="pf">
      <div class="field"><label>PROJECT NAME</label><input id="pn" required maxlength="100"></div>
      <div class="field"><label>PURPOSE</label><textarea id="pd" required maxlength="1000" rows="4"></textarea></div>
      <div class="field"><label>OPTIONAL ATTACHMENT</label><input id="pfile" type="file"></div>
      <button class="btn">SUBMIT FOR CEO APPROVAL →</button>
    </form>`);
  $('pf').onsubmit=async e=>{
    e.preventDefault();
    try{
      const file=$('pfile').files[0];
      let attachment=null;
      if(file) attachment=await uploadStorage(file,`projects/${currentUser.uid}/${Date.now()}_${safeFile(file.name)}`);
      await db.collection('projects').add({name:$('pn').value.trim(),description:$('pd').value.trim(),ownerUid:currentUser.uid,ownerName:currentProfile?.name||'',ownerUsername:currentProfile?.username||'',status:'pending',attachment,createdAt:firebase.firestore.FieldValue.serverTimestamp(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()});
      closeModal(); toast('Project submitted to leadership.'); loadProjects(); if(isAdmin()) loadAdmin();
    }catch(err){ toast(friendly(err)); }
  };
}

async function loadProjects(){
  const el=$('projectList'); if(!el||!db||!currentUser)return;
  try{
    const q=await db.collection('projects').where('ownerUid','==',currentUser.uid).limit(50).get();
    el.innerHTML=q.empty?'<div class="activity-item"><span>No projects yet.</span><small>READY</small></div>':'';
    q.forEach(d=>{const p=d.data();el.innerHTML+=`<div class="activity-item"><span><b>${esc(p.name)}</b><small>${esc(p.description||'')}</small></span><small>${esc((p.status||'pending').toUpperCase())}</small></div>`;});
    const stat=$('statProjects'); if(stat)stat.textContent=q.size;
  }catch(err){ el.innerHTML=`<div class="activity-item"><span>Projects unavailable.</span><small>${esc(err.message||'ERROR')}</small></div>`; }
}

function openRequest(kind){
  openModal('TALK TO '+kind,`
    <form class="form" id="rf">
      <div class="field"><label>SUBJECT</label><input id="rs" required maxlength="120" placeholder="What do you need help with?"></div>
      <div class="field"><label>MESSAGE</label><textarea id="rm" required maxlength="2000" rows="6" placeholder="Write your request…"></textarea></div>
      <button class="btn">SEND REQUEST →</button>
    </form>`);
  $('rf').onsubmit=async e=>{
    e.preventDefault();
    try{
      await db.collection(kind==='CEO'?'ceoRequests':'cmoRequests').add({fromUid:currentUser.uid,fromName:currentProfile?.name||'',fromUsername:currentProfile?.username||'',fromEmail:currentUser.email||'',subject:$('rs').value.trim(),message:$('rm').value.trim(),status:'open',createdAt:firebase.firestore.FieldValue.serverTimestamp()});
      closeModal(); toast(kind+' request sent.');
    }catch(err){toast(friendly(err));}
  };
}

function safeFile(name){return String(name||'file').replace(/[^a-zA-Z0-9._-]/g,'_').slice(-120);}
async function uploadStorage(file,path){
  if(!file) return null;
  if(file.size>20*1024*1024) throw Error('File is too large. Maximum size is 20 MB.');
  const ref=storage.ref(path); const task=await ref.put(file); return {path, name:file.name, size:file.size, type:file.type||'application/octet-stream', url:await task.ref.getDownloadURL()};
}
function openFileUpload(){
  if(!isAdmin() && String(currentProfile?.approvalStatus||'pending')!=='approved'){ return toast('FILES LOCKED — waiting for CEO approval.'); }
  openModal('UPLOAD FILE',`<form class="form" id="ff"><div class="field"><label>FILE</label><input id="ufile" type="file" required></div><div class="field"><label>DESCRIPTION</label><input id="fdesc" maxlength="200" placeholder="What is this file?"></div><button class="btn">UPLOAD TO LIBRARY →</button></form>`);
  $('ff').onsubmit=async e=>{e.preventDefault();try{const f=$('ufile').files[0];const data=await uploadStorage(f,`files/${currentUser.uid}/${Date.now()}_${safeFile(f.name)}`);await db.collection('files').add({ownerUid:currentUser.uid,ownerName:currentProfile?.name||'',ownerUsername:currentProfile?.username||'',description:$('fdesc').value.trim(),file:data,status:'active',createdAt:firebase.firestore.FieldValue.serverTimestamp()});closeModal();toast('File uploaded.');loadFiles();if(isAdmin())loadAdmin();}catch(err){toast(friendly(err));}};
}
async function loadFiles(){
  const el=$('fileList');if(!el||!db||!currentUser)return;
  try{let q=isAdmin()?await db.collection('files').limit(80).get():await db.collection('files').where('ownerUid','==',currentUser.uid).limit(50).get();el.innerHTML=q.empty?'<div class="activity-item"><span>No files yet.</span><small>LIBRARY</small></div>':'';q.forEach(d=>{const x=d.data();el.innerHTML+=fileRow(d.id,x,false);});}catch(err){el.innerHTML='<div class="activity-item"><span>File library unavailable.</span></div>';}
}
function fileRow(id,x,admin){return `<div class="activity-item"><span><b>${esc(x.file?.name||'File')}</b><small>${esc(x.ownerName||'')} · ${esc(x.description||'')}</small></span><span><a class="mini-btn" href="${esc(x.file?.url||'#')}" target="_blank" rel="noopener">OPEN</a>${admin?` <button class="mini-btn light" onclick="deleteFile('${id}')">DELETE</button>`:''}</span></div>`;}
async function deleteFile(id){if(!isAdmin())return toast('Admin access required.');if(!confirm('Delete this file record?'))return;try{await db.collection('files').doc(id).delete();toast('File removed.');loadFiles();loadAdmin();}catch(e){toast(friendly(e));}}

let taskCrewCache=[];
async function getVerifiedCrew(){
  if(taskCrewCache.length) return taskCrewCache;
  const snap=await db.collection('users').where('verified','==',true).limit(200).get();
  taskCrewCache=[]; snap.forEach(d=>taskCrewCache.push({uid:d.id,...d.data()}));
  return taskCrewCache;
}
function taskCrewOptions(list){
  return list.map(p=>`<option value="@${esc(String(p.username||'').toLowerCase())}">${esc(p.name||'Crew')} · @${esc(p.username||'')}</option>`).join('');
}
async function openTaskModal(){
  if(!isCEO()) return toast('Only the CEO can assign organization tasks.');
  let crew=[]; try{crew=await getVerifiedCrew();}catch(e){return toast('Crew directory could not load. Check Firestore access.');}
  openModal('ASSIGN TASK',`<form class="form" id="tf"><div class="field"><label>ASSIGN TO</label><input id="tto" list="taskCrewList" required placeholder="@username" autocomplete="off"><datalist id="taskCrewList">${taskCrewOptions(crew)}</datalist><small class="field-hint">${crew.length} verified crew member${crew.length===1?'':'s'} available</small></div><div class="field"><label>TASK</label><input id="ttitle" required maxlength="120" placeholder="Task title"></div><div class="field"><label>BRIEF</label><textarea id="tbody" rows="5" maxlength="2000" required placeholder="What needs to be done?"></textarea></div><div class="field"><label>PRIORITY</label><select id="tpriority"><option>normal</option><option>high</option><option>urgent</option></select></div><button class="btn">ASSIGN TASK →</button></form>`);
  $('tf').onsubmit=async e=>{
    e.preventDefault();
    try{
      let u=$('tto').value.trim().replace(/^@/,'').toLowerCase();
      if(!/^[a-z0-9_.-]{3,24}$/.test(u)) throw Error('Choose a valid @username from the available crew list.');
      let profDoc=null;
      const local=crew.find(p=>String(p.username||'').toLowerCase()===u);
      if(local) profDoc={id:local.uid,data:()=>local};
      if(!profDoc){
        const prof=await db.collection('users').where('username','==',u).limit(1).get();
        if(!prof.empty) profDoc=prof.docs[0];
      }
      if(!profDoc){
        const idx=await db.collection('usernames').doc(u).get();
        if(idx.exists){const uid0=idx.data().uid;const fallback=await db.collection('users').doc(uid0).get();if(fallback.exists)profDoc=fallback;}
      }
      if(!profDoc) throw Error('Username not found. Select a username shown in the available crew list.');
      const uid=profDoc.id, pdata=profDoc.data();
      if(pdata.verified!==true) throw Error('That crew member is not verified.');
      await db.collection('tasks').add({assigneeUid:uid,assigneeUsername:u,assigneeName:pdata.name||'',title:$('ttitle').value.trim(),description:$('tbody').value.trim(),priority:$('tpriority').value,status:'assigned',assignedBy:currentUser.uid,assignedByName:currentProfile?.name||'CEO',createdAt:firebase.firestore.FieldValue.serverTimestamp(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()});
      closeModal(); toast(`Task assigned to @${u}.`); loadTasks(); loadAdmin();
    }catch(err){toast(friendly(err));}
  };
}
async function loadTasks(){
  const el=$('taskList');if(!el||!db||!currentUser)return;
  try{
    const q=await db.collection('tasks').where('assigneeUid','==',currentUser.uid).limit(80).get();
    const rows=[];q.forEach(d=>rows.push({id:d.id,x:d.data()}));
    rows.sort((a,b)=>(b.x.createdAt?.seconds||0)-(a.x.createdAt?.seconds||0));
    el.innerHTML=rows.length?rows.map(r=>taskRow(r.id,r.x,false)).join(''):'<div class="activity-item"><span>No tasks assigned.</span><small>ALL CLEAR</small></div>';
  }catch(e){el.innerHTML='<div class="activity-item"><span>Tasks unavailable.</span><small>'+esc(friendly(e))+'</small></div>';}
}
function taskRow(id,x,admin){return `<div class="activity-item"><span><b>${esc(x.title)}</b><small>${esc(x.description||'')} · @${esc(x.assigneeUsername||'')}</small></span><span><small>${esc((x.priority||'normal').toUpperCase())} · ${esc((x.status||'assigned').toUpperCase())}</small>${admin?`<button class="mini-btn" onclick="closeTask('${id}')">${x.status==='completed'?'DONE':'CLOSE'}</button>`:`<button class="mini-btn" onclick="updateTaskStatus('${id}','in_progress')">START</button> <button class="mini-btn light" onclick="updateTaskStatus('${id}','completed')">DONE</button>`}</span></div>`;}
async function updateTaskStatus(id,status){try{await db.collection('tasks').doc(id).update({status,updatedAt:firebase.firestore.FieldValue.serverTimestamp()});loadTasks();toast('Task updated.');}catch(e){toast(friendly(e));}}
async function closeTask(id){if(!isCEO())return;await db.collection('tasks').doc(id).update({status:'closed',updatedAt:firebase.firestore.FieldValue.serverTimestamp()});loadAdmin();loadTasks();}

function openGrazeUpload(){
  if(!isAdmin() && String(currentProfile?.approvalStatus||'pending')!=='approved'){ return toast('GRAZE SPACE LOCKED — waiting for CEO approval.'); }
  openModal('GRAZE SPACE / NEW OBSERVATION',`<form class="form" id="gf"><div class="field"><label>NIGHT SKY PHOTO</label><input id="gfile" type="file" accept="image/*" required></div><div class="field"><label>CAPTION</label><input id="gcaption" maxlength="180" placeholder="Orion over Bettiah…"></div><div class="field"><label>LOCATION / OBSERVATION NOTE</label><input id="glocation" maxlength="180" placeholder="Optional location or note"></div><button class="btn">SUBMIT FOR REVIEW →</button></form>`);
  $('gf').onsubmit=async e=>{e.preventDefault();try{const f=$('gfile').files[0];if(!f.type.startsWith('image/'))throw Error('Please select an image.');const data=await uploadStorage(f,`graze/${currentUser.uid}/${Date.now()}_${safeFile(f.name)}`);await db.collection('graze').add({ownerUid:currentUser.uid,ownerName:currentProfile?.name||'',ownerUsername:currentProfile?.username||'',caption:$('gcaption').value.trim(),location:$('glocation').value.trim(),image:data,status:'pending',createdAt:firebase.firestore.FieldValue.serverTimestamp()});closeModal();toast('Graze observation submitted for approval.');loadGraze();if(isAdmin())loadAdmin();}catch(err){toast(friendly(err));}};
}
async function loadGraze(){
  const el=$('myGrazeList');if(!el||!db||!currentUser)return;
  try{
    const q=await db.collection('graze').where('ownerUid','==',currentUser.uid).limit(80).get();
    const rows=[];q.forEach(d=>rows.push({id:d.id,x:d.data()}));
    rows.sort((a,b)=>(b.x.createdAt?.seconds||0)-(a.x.createdAt?.seconds||0));
    el.innerHTML=rows.length?rows.map(({x})=>`<article class="gallery-card"><img src="${esc(x.image?.url||'')}" loading="lazy" alt="${esc(x.caption||'Graze observation')}"><div class="gallery-card-copy"><b>${esc(x.caption||'Untitled observation')}</b><small>${esc(x.location||'')} · ${(x.status||'pending').toUpperCase()}</small></div></article>`).join(''):'<div class="activity-item"><span>No observations yet.</span><small>READY FOR YOUR FIRST CAPTURE</small></div>';
  }catch(e){el.innerHTML='<div class="activity-item"><span>Graze Space unavailable.</span><small>'+esc(friendly(e))+'</small></div>';}
}
function bindGrazeForm(){
  const form=$('grazeForm'); if(!form)return;
  form.addEventListener('submit',async e=>{
    e.preventDefault();
    if(!isAdmin() && String(currentProfile?.approvalStatus||'pending')!=='approved') return toast('GRAZE SPACE LOCKED — waiting for CEO approval.');
    try{
      const f=$('grazeFile')?.files?.[0]; if(!f) throw Error('Choose a sky image first.');
      if(!f.type.startsWith('image/')) throw Error('Please select an image file.');
      if(f.size>20*1024*1024) throw Error('Image is too large. Maximum 20 MB.');
      const data=await uploadStorage(f,`graze/${currentUser.uid}/${Date.now()}_${safeFile(f.name)}`);
      await db.collection('graze').add({ownerUid:currentUser.uid,ownerName:currentProfile?.name||'',ownerUsername:currentProfile?.username||'',caption:$('grazeTitle').value.trim(),location:$('grazeLocation').value.trim(),image:data,status:'pending',createdAt:firebase.firestore.FieldValue.serverTimestamp()});
      form.reset(); toast('Graze submitted — sent to the moderation queue.'); loadGraze();
    }catch(err){toast(friendly(err));}
  });
}

async function approveUser(uid){
  if(!isCEO()) return toast('Only the CEO can approve accounts.');
  const id=prompt('Assign final XPS ID','XPS-'+Math.floor(100+Math.random()*900)); if(!id)return;
  const x=id.trim().toUpperCase();
  try{const taken=await db.collection('users').where('xpsId','==',x).limit(1).get();if(!taken.empty)return toast('XPS ID already assigned.');await db.collection('users').doc(uid).update({xpsId:x,approvalStatus:'approved',verified:true,approvedBy:CEO_EMAIL,approvedAt:firebase.firestore.FieldValue.serverTimestamp(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()});await createUserNotification(uid,'Crew account approved','Your XPACE OS access is now active.','✓','view:home');toast('Crew approved.');loadAdmin();}catch(e){toast(friendly(e));}
}
async function rejectUser(uid){
  if(!isCEO())return toast('Only the CEO can reject accounts.'); if(!confirm('Reject this account?'))return;
  try{await db.collection('users').doc(uid).update({approvalStatus:'rejected',verified:false,rejectedBy:CEO_EMAIL,rejectedAt:firebase.firestore.FieldValue.serverTimestamp()});await createUserNotification(uid,'Account update','Your crew account was rejected by the CEO.','!','view:home');toast('Account rejected.');loadAdmin();}catch(e){toast(friendly(e));}
}

async function loadAdmin(){
  const table=$('pendingTable'); if(!table||!db)return;
  const allowed=isAdmin(); if(!allowed){table.innerHTML='<tr><td colspan="5">Admin access unavailable.</td></tr>';return;}
  try{const q=await db.collection('users').where('approvalStatus','==','pending').limit(100).get();table.innerHTML='';if(q.empty)table.innerHTML='<tr><td colspan="5">No pending accounts.</td></tr>';q.forEach(doc=>{const p=doc.data();const created=p.createdAt?.toDate?.()||new Date();const age=Math.max(0,Math.floor((Date.now()-created.getTime())/36e5));table.innerHTML+=`<tr><td><b>${esc(p.name)}</b><br><span class="sub">@${esc(p.username)}</span></td><td>${esc(p.email)}</td><td>${esc(p.requestedXpsId||'—')}</td><td>${age}h</td><td>${isCEO()?`<button class="mini-btn" onclick="approveUser('${doc.id}')">APPROVE</button> <button class="mini-btn light" onclick="rejectUser('${doc.id}')">REJECT</button>`:'<span class="sub">CEO ONLY</span>'}</td></tr>`;});
    loadAdminTasks();loadRequestInbox();loadProjectRequests();loadGrazeModeration();loadAdminFiles();
  }catch(e){table.innerHTML='<tr><td colspan="5">Admin data unavailable.</td></tr>';}
}
async function loadAdminTasks(){const el=$('adminTaskList');if(!el)return;const q=await db.collection('tasks').limit(80).get();el.innerHTML=q.empty?'<div class="activity-item"><span>No assigned work.</span></div>':'';q.forEach(d=>el.innerHTML+=taskRow(d.id,d.data(),true));}
async function loadRequestInbox(){const el=$('requestInbox');if(!el)return;const [a,b]=await Promise.all([db.collection('ceoRequests').orderBy('createdAt','desc').limit(50).get(),db.collection('cmoRequests').orderBy('createdAt','desc').limit(50).get()]);const rows=[];a.forEach(d=>rows.push({...d.data(),id:d.id,kind:'CEO'}));b.forEach(d=>rows.push({...d.data(),id:d.id,kind:'CMO'}));rows.sort((x,y)=>(y.createdAt?.seconds||0)-(x.createdAt?.seconds||0));el.innerHTML=rows.length?rows.map(x=>`<div class="activity-item"><span><b>${esc(x.kind)} · ${esc(x.subject||'Request')}</b><small>@${esc(x.fromUsername||'crew')} · ${esc(x.message||'')}</small></span><button class="mini-btn" onclick="replyRequest('${x.kind}','${x.id}','${esc(x.fromUsername||'crew')}')">REPLY</button></div>`).join(''):'<div class="activity-item"><span>No requests.</span></div>';}
function replyRequest(kind,id,user){openModal('REPLY TO @'+user,`<form class="form" id="replyf"><div class="field"><label>REPLY</label><textarea id="replym" rows="6" required></textarea></div><button class="btn">SEND REPLY →</button></form>`);$('replyf').onsubmit=async e=>{e.preventDefault();try{const c=kind==='CEO'?'ceoRequests':'cmoRequests';await db.collection(c).doc(id).update({status:'replied',reply:$('replym').value.trim(),repliedBy:currentUser.email,repliedAt:firebase.firestore.FieldValue.serverTimestamp()});closeModal();toast('Reply sent.');loadRequestInbox();}catch(err){toast(friendly(err));}};}
async function loadProjectRequests(){const el=$('projectRequests');if(!el)return;const q=await db.collection('projects').where('status','==','pending').limit(80).get();el.innerHTML=q.empty?'<div class="activity-item"><span>No project requests.</span></div>':'';q.forEach(d=>{const x=d.data();el.innerHTML+=`<div class="activity-item"><span><b>${esc(x.name)}</b><small>${esc(x.description||'')} · @${esc(x.ownerUsername||'')}</small></span><span><button class="mini-btn" onclick="moderateProject('${d.id}','approved')">APPROVE</button> <button class="mini-btn light" onclick="moderateProject('${d.id}','rejected')">REJECT</button></span></div>`;});}
async function moderateProject(id,status){if(!isCEO())return toast('Only the CEO can approve projects.');try{await db.collection('projects').doc(id).update({status,approvedBy:currentUser.email,approvedAt:firebase.firestore.FieldValue.serverTimestamp(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()});toast('Project '+status+'.');loadAdmin();loadProjects();}catch(e){toast(friendly(e));}}
let grazeModerationUnsub=null;
async function loadGrazeModeration(){
  const el=$('grazeModeration'); if(!el || !db || !isAdmin()) return;
  try{
    if(grazeModerationUnsub) grazeModerationUnsub();
    grazeModerationUnsub=db.collection('graze').where('status','==','pending').limit(80).onSnapshot(snap=>{
      el.innerHTML=snap.empty?'<div class="activity-item"><span>No pending observations.</span></div>':'';
      snap.forEach(d=>{const x=d.data();el.innerHTML+=`<article class="gallery-card"><img src="${esc(x.image?.url||'')}" alt=""><div class="gallery-card-copy"><b>${esc(x.caption||'Untitled')}</b><small>@${esc(x.ownerUsername||'crew')} · ${esc(x.location||'')}</small><span><button class="mini-btn" onclick="moderateGraze('${d.id}','approved')">PUBLISH</button> <button class="mini-btn light" onclick="moderateGraze('${d.id}','rejected')">REJECT</button></span></div></article>`;});
    },err=>{el.innerHTML='<div class="activity-item"><span>Graze moderation unavailable.</span><small>'+esc(friendly(err))+'</small></div>';});
  }catch(e){el.innerHTML='<div class="activity-item"><span>Graze moderation unavailable.</span></div>';}
}
async function moderateGraze(id,status){if(!isAdmin())return toast('Admin access required.');try{await db.collection('graze').doc(id).update({status,moderatedBy:currentUser.email,moderatedAt:firebase.firestore.FieldValue.serverTimestamp()});const snap=await db.collection('graze').doc(id).get(); const owner=snap.exists?snap.data().ownerUid:null; if(owner) await createUserNotification(owner,status==='approved'?'Graze published':'Graze rejected',status==='approved'?'Your sky observation is now live in Gallery.':'Your sky observation was rejected by moderation.',status==='approved'?'✦':'!','view:graze'); toast(status==='approved'?'Published to Gallery.':'Observation rejected.');loadGrazeModeration();loadGraze();}catch(e){toast(friendly(e));}}
async function loadAdminFiles(){const el=$('adminFiles');if(!el)return;const q=await db.collection('files').limit(80).get();el.innerHTML=q.empty?'<div class="activity-item"><span>No files uploaded.</span></div>':'';q.forEach(d=>el.innerHTML+=fileRow(d.id,d.data(),true));}

async function loadPublicGallery(){
  const el=$('publicGallery'); if(!el||!db)return;
  try{const q=await db.collection('graze').where('status','==','approved').limit(18).get();el.innerHTML=q.empty?'<div class="gallery-loading">No observations published yet.</div>':'';q.forEach(d=>{const x=d.data();el.innerHTML+=`<article class="public-gallery-card"><img src="${esc(x.image?.url||'')}" loading="lazy" alt="${esc(x.caption||'Night sky observation')}"><div><b>${esc(x.caption||'Night sky observation')}</b><small>${esc(x.ownerName||'xpacespace crew')} · ${esc(x.location||'')}</small></div></article>`;});}catch(e){el.innerHTML='<div class="gallery-loading">Gallery is temporarily unavailable.</div>';}
}


/* ---------- V51 direct chat ---------- */
let chatPeopleCache=[];
let chatActiveUid=null;
let chatActiveUnsub=null;
function chatIdFor(a,b){return [a,b].sort().join('_');}
function escapeChat(s){return esc(String(s||''));}
async function loadChatPeople(){
  const el=$('chatPeople'); if(!el||!db||!currentUser)return;
  try{
    const q=await db.collection('users').where('verified','==',true).limit(200).get();
    chatPeopleCache=[];q.forEach(d=>{if(d.id!==currentUser.uid)chatPeopleCache.push({uid:d.id,...d.data()});});
    renderChatPeople(chatPeopleCache);
  }catch(e){el.innerHTML='<div class="activity-item"><span>Crew unavailable.</span><small>CHECK FIRESTORE ACCESS</small></div>';}
}
function renderChatPeople(items){
  const el=$('chatPeople'); if(!el)return;
  if(!items.length){el.innerHTML='<div class="chat-nopeople">No verified crew found.</div>';return;}
  el.innerHTML=items.map(p=>`<button type="button" class="chat-person" data-chat-uid="${esc(p.uid)}"><span class="chat-avatar">${esc((p.name||p.username||'X').charAt(0).toUpperCase())}</span><span><b>${escapeChat(p.name||'Crew Member')}</b><small>@${escapeChat(p.username||'crew')} · ${escapeChat(p.designation||'CREW')}</small></span></button>`).join('');
}
function openChatWith(uid){
  const p=chatPeopleCache.find(x=>x.uid===uid); if(!p||!currentUser)return;
  chatActiveUid=uid; $('chatEmpty').style.display='none'; $('chatActive').style.display='flex';
  $('chatPartnerName').textContent=p.name||'Crew Member'; $('chatPartnerMeta').textContent='@'+(p.username||'crew'); $('chatInput').focus();
  if(chatActiveUnsub)chatActiveUnsub();
  const cid=chatIdFor(currentUser.uid,uid);
  chatActiveUnsub=db.collection('directChats').doc(cid).collection('messages').orderBy('createdAt','asc').limitToLast(100).onSnapshot(snap=>{
    const el=$('chatMessages'); if(!el)return; el.innerHTML='';
    snap.forEach(d=>{const x=d.data();const mine=x.senderUid===currentUser.uid;el.innerHTML+=`<div class="chat-bubble-row ${mine?'mine':''}"><div class="chat-bubble">${escapeChat(x.text)}<small>${timeLabel(x.createdAt)}</small></div></div>`;});
    el.scrollTop=el.scrollHeight;
  },e=>{ $('chatMessages').innerHTML='<div class="chat-nopeople">Chat could not load. Check Firestore rules.</div>'; });
}
function timeLabel(ts){const d=ts?.toDate?.()||new Date(ts||Date.now());return d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});}
async function sendChatMessage(e){
  e.preventDefault(); if(!chatActiveUid||!currentUser)return; const input=$('chatInput');const text=input.value.trim();if(!text)return;
  const cid=chatIdFor(currentUser.uid,chatActiveUid);const chatRef=db.collection('directChats').doc(cid);
  try{
    await chatRef.set({participants:[currentUser.uid,chatActiveUid],updatedAt:firebase.firestore.FieldValue.serverTimestamp(),lastMessage:text,lastSenderUid:currentUser.uid},{merge:true});
    await chatRef.collection('messages').add({senderUid:currentUser.uid,senderName:currentProfile?.name||'',text,createdAt:firebase.firestore.FieldValue.serverTimestamp()});
    input.value='';
    const partner=chatPeopleCache.find(x=>x.uid===chatActiveUid); void partner; // Firebase Cloud Function creates the recipient notification.
  }catch(e2){toast(friendly(e2));}
}
function bindChat(){
  $('chatPeople')?.addEventListener('click',e=>{const b=e.target.closest('[data-chat-uid]');if(b)openChatWith(b.dataset.chatUid);});
  $('chatPeopleSearch')?.addEventListener('input',e=>{const t=e.target.value.toLowerCase().trim();renderChatPeople(chatPeopleCache.filter(p=>(p.name+' '+p.username+' '+p.designation).toLowerCase().includes(t)));});
  $('chatForm')?.addEventListener('submit',sendChatMessage);
  $('chatCloseBtn')?.addEventListener('click',()=>{$('chatActive').style.display='none';$('chatEmpty').style.display='grid';chatActiveUid=null;if(chatActiveUnsub){chatActiveUnsub();chatActiveUnsub=null;}});
}
async function repairUsernameIndex(profile){
  if(!currentUser||!profile?.username||profile.username==='crew-'+String(currentUser.uid).slice(0,8).toLowerCase())return;
  try{const ref=db.collection('usernames').doc(String(profile.username).toLowerCase());const snap=await ref.get();if(!snap.exists)await ref.set({uid:currentUser.uid,username:String(profile.username).toLowerCase(),createdAt:firebase.firestore.FieldValue.serverTimestamp()});}catch(e){console.warn('username index repair skipped',e);}
}

/* ---------- workspace boot ---------- */
async function boot(){
  if(!initFirebase()){
    $('boot').innerHTML='<div class="login-box"><div class="auth-shell"><div class="auth-card"><h2>Firebase configuration missing</h2><p class="sub">Check js/firebase-config.js.</p></div></div></div>';
    return;
  }

  auth.onAuthStateChanged(async user=>{
    if(!user){
      location.href='index.html';
      return;
    }

    currentUser=user;
    exposeRuntime();

    // Always normalize the signed-in email against the two authoritative addresses.
    const normalizedEmail=cleanEmail(user.email);

    $('boot').style.display='none';
    $('app').style.display='grid';

    nav();
  bindSearchProfile();

    const userRef=db.collection('users').doc(user.uid);

    userRef.onSnapshot(async snap=>{
      if(!snap.exists){
        // A freshly authenticated account can briefly exist before its profile write.
        if(normalizedEmail===CEO_EMAIL || normalizedEmail===CMO_EMAIL){
          const role=roleForEmail(normalizedEmail);
          currentProfile={
            uid:user.uid,email:normalizedEmail,
            name:user.displayName || (role==='ceo'?'CEO':'CMO'),
            role,approvalStatus:'approved',verified:true,
            xpsId:role==='ceo'?'XPS-CEO':'XPS-CMO',
            designation:role==='ceo'?'CEO / God Admin':'CMO / Admin'
          };
          await userRef.set({
            ...currentProfile,
            createdAt:firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt:firebase.firestore.FieldValue.serverTimestamp()
          },{merge:true});
          render(currentProfile);
          ensureProfileGate(currentProfile);
          return;
        }

        // Recover Auth accounts created before/without a Firestore profile.
        // The profile is created under the signed-in UID, which is permitted by
        // the Firestore create rule for ordinary crew members.
        const recoveryUsername = 'crew-' + String(user.uid).slice(0,8).toLowerCase();
        currentProfile = {
          uid:user.uid,
          name:user.displayName || (normalizedEmail.split('@')[0] || 'Crew Member'),
          username:recoveryUsername,
          email:normalizedEmail,
          requestedXpsId:'XPS-PENDING',
          xpsId:null,
          role:'member',
          designation:null,
          mobile:null,
          approvalStatus:'pending',
          verified:false
        };
        try{
          await userRef.set({
            ...currentProfile,
            createdAt:firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt:firebase.firestore.FieldValue.serverTimestamp()
          },{merge:false});
          repairUsernameIndex(currentProfile);
          render(currentProfile);
          await ensureProfileGate(currentProfile);
          return;
        }catch(recoveryErr){
          // Never trap a valid authenticated user behind an error screen.
          // Keep the shell open in pending mode; operational actions remain locked.
          currentProfile={...currentProfile, recoveryError:true, approvalStatus:'pending', verified:false};
          window.currentProfile=currentProfile;
          render(currentProfile);
          ensureProfileGate(currentProfile);
          toast('Profile sync is pending. Workspace opened in restricted mode.');
          return;
        }
      }

      currentProfile=snap.data();
      window.currentProfile=currentProfile;

      // Authoritative email recognition: don't rely only on a stale Firestore role.
      const authoritativeRole=roleForEmail(normalizedEmail);
      if(authoritativeRole==='ceo' && currentProfile.role!=='ceo'){
        currentProfile={...currentProfile,role:'ceo',approvalStatus:'approved',verified:true,xpsId:currentProfile.xpsId||'XPS-CEO',designation:currentProfile.designation||'CEO / God Admin'};
      }
      if(authoritativeRole==='admin' && currentProfile.role!=='admin'){
        currentProfile={...currentProfile,role:'admin',approvalStatus:'approved',verified:true,xpsId:currentProfile.xpsId||'XPS-CMO',designation:currentProfile.designation||'CMO / Admin'};
      }

      window.currentProfile=currentProfile;
      repairUsernameIndex(currentProfile);
      render(currentProfile);
      await ensureProfileGate(currentProfile);
    });
  });
}

async function logout(){
  if(auth) await auth.signOut();
  location.href='index.html';
}

document.addEventListener('DOMContentLoaded',()=>{
  if($('publicGallery')){ initFirebase(); loadPublicGallery(); }
  if($('loginForm')){
    bindIndex();
    initFirebase();
    if(auth) auth.onAuthStateChanged(u=>{ if(u) location.href='workspace.html'; });
  }

  if($('app')){
    $('onboardingForm')?.addEventListener('submit',saveOnboarding);
    boot();
  }
});

window.logout=logout;
window.openProjectModal=openProjectModal;
window.openRequest=openRequest;
window.closeModal=closeModal;
window.approveUser=approveUser;
window.rejectUser=rejectUser;
window.openTaskModal=openTaskModal;
window.updateTaskStatus=updateTaskStatus;
window.closeTask=closeTask;
window.openGrazeUpload=openGrazeUpload;
window.openFileUpload=openFileUpload;
window.deleteFile=deleteFile;
window.replyRequest=replyRequest;
window.openProfile=openProfile;
window.openProfileEditor=openProfileEditor;
window.searchXpace=searchXpace;
window.moderateProject=moderateProject;
window.moderateGraze=moderateGraze;
window.showAuth=window.showAuth || function(mode){
  const login=mode==='login';
  $('loginForm').style.display=login?'grid':'none';
  $('signupForm').style.display=login?'none':'grid';
  $('tabLogin').classList.toggle('active',login);
  $('tabSignup').classList.toggle('active',!login);
  $('auth')?.scrollIntoView({behavior:'smooth',block:'center'});
};

})();

/* ================= V50 APP EXPERIENCE ================= */
(function(){
  const V50={unread:0,installPrompt:null,notifications:[]};
  const q=id=>document.getElementById(id);
  function appToast(msg){const el=q('appToast');if(!el)return;el.textContent=msg;el.classList.add('show');clearTimeout(window.__xpToast);window.__xpToast=setTimeout(()=>el.classList.remove('show'),2200)}
  function sheet(id,open){const el=q(id),back=q('sheetBackdrop');if(!el)return;el.classList.toggle('open',open);el.setAttribute('aria-hidden',String(!open));back?.classList.toggle('open',open)}
  function setUnread(n){V50.unread=Math.max(0,Number(n)||0);const dot=q('notificationDot');const badge=q('taskBadge');if(dot){dot.textContent=V50.unread>99?'99+':V50.unread;dot.classList.toggle('show',V50.unread>0)}if(badge){badge.textContent=V50.unread>9?'9+':V50.unread;badge.classList.toggle('show',V50.unread>0)}}
  function timeAgo(ts){const d=ts?.toDate?.()||new Date(ts||Date.now());const s=Math.max(1,Math.floor((Date.now()-d.getTime())/1000));if(s<60)return s+'s';if(s<3600)return Math.floor(s/60)+'m';if(s<86400)return Math.floor(s/3600)+'h';return Math.floor(s/86400)+'d'}
  function renderNotifications(items){const el=q('notificationList');if(!el)return;V50.notifications=items||[];setUnread(items.filter(x=>!x.read).length);if(!items.length){el.innerHTML='<div class="empty-notifications"><strong>All clear</strong>No new crew notifications.</div>';return}el.innerHTML=items.map(x=>`<button class="notification-item ${x.read?'':'unread'}" data-notification-id="${String(x.id||'').replace(/[^a-zA-Z0-9_-]/g,'')}" data-link="${String(x.link||'').replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"><span class="notification-icon">${x.icon||'✦'}</span><span class="notification-copy"><b>${esc(x.title||'XPACE update')}</b><p>${esc(x.body||'Something changed in your workspace.')}</p><small>${timeAgo(x.createdAt)} AGO</small></span><span class="notification-unread" style="${x.read?'visibility:hidden':''}"></span></button>`).join('')}
  async function loadNotifications(){
    if(!window.db||!window.currentUser)return;
    try{
      const snap=await db.collection('notifications').where('uid','==',currentUser.uid).limit(40).get();
      const arr=[];snap.forEach(d=>arr.push({id:d.id,...d.data()}));arr.sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0));renderNotifications(arr);
    }catch(e){
      // Firestore may have no composite/index yet. The app still works with local events.
      renderNotifications([]);
    }
  }
  async function markNotification(id){if(!window.db||!id)return;try{await db.collection('notifications').doc(id).update({read:true,readAt:firebase.firestore.FieldValue.serverTimestamp()})}catch(e){}loadNotifications()}
  function localNotification(title,body,icon='✦',link=''){const item={id:'local-'+Date.now(),title,body,icon,link,read:false,createdAt:new Date()};V50.notifications.unshift(item);renderNotifications(V50.notifications.slice(0,40));appToast(title);if('Notification' in window&&Notification.permission==='granted'){try{new Notification(title,{body,icon:'assets/favicon-192.png'})}catch(e){}}}
  async function requestNotifications(){if(!('Notification' in window))return;if(Notification.permission==='default'){try{await Notification.requestPermission()}catch(e){}}}
  function commandItems(term=''){
    const all=[['⌂','Open Home','home','HOME'],['◎','Open Missions','missions','MISSIONS'],['◇','Open Projects','projects','PROJECTS'],['✓','Open Tasks','tasks','TASKS'],['✦','Open Graze Space','graze','GRAZE'],['◌','Open Comms','comms','COMMS'],['♙','Open Crew','crew','CREW'],['⌕','Search XPACE','search','SEARCH'],['◉','Open Profile','profile','PROFILE'],['□','Open Files','files','FILES'],['🔔','Open Notifications','__notifications','NOTIFICATIONS'],['↪','Sign out','__logout','ACCOUNT']];
    const t=term.toLowerCase().trim();return all.filter(x=>(x[1]+' '+x[3]).toLowerCase().includes(t)).map(x=>`<button class="command-item" data-command="${x[2]}"><span>${x[0]}</span><b>${x[1]}</b><small class="command-key">${x[3]}</small></button>`).join('')}
  function openCommand(){const el=q('commandList');if(el)el.innerHTML=commandItems();sheet('commandSheet',true);setTimeout(()=>q('commandSearch')?.focus(),150)}
  function handleCommand(cmd){sheet('commandSheet',false);if(cmd==='__notifications'){sheet('notificationSheet',true);loadNotifications();return}if(cmd==='__logout'){window.logout?.();return}document.querySelector(`[data-view="${cmd}"]`)?.click();}
  function installSetup(){
    window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();V50.installPrompt=e;if(!localStorage.getItem('xp_install_dismissed'))q('installBanner')?.classList.add('show')});
    q('installAction')?.addEventListener('click',async()=>{if(V50.installPrompt){V50.installPrompt.prompt();try{await V50.installPrompt.userChoice}catch(e){}V50.installPrompt=null}q('installBanner')?.classList.remove('show')});
    q('installDismiss')?.addEventListener('click',()=>{localStorage.setItem('xp_install_dismissed','1');q('installBanner')?.classList.remove('show')});
  }
  function bind(){
    q('notificationBtn')?.addEventListener('click',()=>{sheet('notificationSheet',true);loadNotifications();requestNotifications()});
    q('commandBtn')?.addEventListener('click',openCommand);
    q('appFab')?.addEventListener('click',openCommand);
    q('sheetBackdrop')?.addEventListener('click',()=>{sheet('notificationSheet',false);sheet('commandSheet',false)});
    document.querySelectorAll('[data-close-sheet]').forEach(b=>b.addEventListener('click',()=>{sheet('notificationSheet',false);sheet('commandSheet',false)}));
    q('commandSearch')?.addEventListener('input',e=>{q('commandList').innerHTML=commandItems(e.target.value)});
    q('commandList')?.addEventListener('click',e=>{const b=e.target.closest('[data-command]');if(b)handleCommand(b.dataset.command)});
    q('notificationList')?.addEventListener('click',e=>{const b=e.target.closest('[data-notification-id]');if(!b)return;const id=b.dataset.notificationId;if(id.startsWith('local-')){b.classList.remove('unread');setUnread(V50.notifications.filter(x=>!x.read).length);return}markNotification(id);if(b.dataset.link){if(b.dataset.link.startsWith('view:'))document.querySelector(`[data-view="${b.dataset.link.slice(5)}"]`)?.click();}});
    document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();openCommand()}if(e.key==='Escape'){sheet('notificationSheet',false);sheet('commandSheet',false)}});
    installSetup();
    if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(()=>{});
    // Native-ish touch feedback for buttons.
    document.addEventListener('click',e=>{const b=e.target.closest('button,.btn,.nav-item,.drawer-item');if(b){b.classList.remove('native-pulse');void b.offsetWidth;b.classList.add('native-pulse')}});
    // Back button closes sheets/drawer before navigating away.
    window.addEventListener('popstate',()=>{sheet('notificationSheet',false);sheet('commandSheet',false);document.body.classList.remove('drawer-open')});
  }
  function bootAppLayer(){if(!q('app'))return;bind();bindChat();bindGrazeForm();setTimeout(loadNotifications,900);setTimeout(loadChatPeople,1100);}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bootAppLayer);else bootAppLayer();
  window.xpAppNotify=localNotification;
})();


/* ================= V52 RELEASE EXPERIENCE ================= */
(function(){
  'use strict';
  function xpRender(){
    const p=window.currentProfile||{};
    const xp=Number(p.xp||0); const level=Math.max(1,Math.floor(xp/100)+1); const pct=Math.min(100,xp%100);
    const l=document.getElementById('xpLevel'),v=document.getElementById('xpValue'),b=document.getElementById('xpBar');
    if(l)l.textContent=String(level).padStart(2,'0'); if(v)v.textContent=xp+' XP'; if(b)b.style.width=pct+'%';
  }
  async function pulse(){
    const el=document.getElementById('pulseList'); if(!el||!window.db||!window.currentUser)return;
    try{
      const [n,t]=await Promise.all([
        db.collection('notifications').where('uid','==',currentUser.uid).limit(12).get(),
        db.collection('tasks').where('assigneeUid','==',currentUser.uid).limit(12).get()
      ]);
      const rows=[]; n.forEach(d=>rows.push({at:d.data().createdAt?.seconds||0,label:d.data().title||'Notification',sub:d.data().body||''}));
      t.forEach(d=>rows.push({at:d.data().createdAt?.seconds||0,label:'Task · '+(d.data().title||'Assigned work'),sub:(d.data().status||'assigned').toUpperCase()}));
      rows.sort((a,b)=>b.at-a.at);
      el.innerHTML=rows.slice(0,5).map(x=>`<div class="activity-item"><span><b>${esc(x.label)}</b><small>${esc(x.sub)}</small></span><small>LIVE</small></div>`).join('')||'<div class="activity-item"><span>No recent signals.</span><small>ALL CLEAR</small></div>';
    }catch(e){ el.innerHTML='<div class="activity-item"><span>Pulse waiting for sync.</span></div>'; }
  }
  document.addEventListener('DOMContentLoaded',()=>{setTimeout(()=>{xpRender();pulse()},1400);setInterval(pulse,30000);});
  const oldExpose=window.xpAppNotify; window.xpAppNotify=function(){if(oldExpose)oldExpose.apply(this,arguments);pulse();};
})();
