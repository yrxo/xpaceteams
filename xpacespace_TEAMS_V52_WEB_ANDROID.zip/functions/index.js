const {onSchedule}=require("firebase-functions/v2/scheduler");
const {onCall,HttpsError}=require("firebase-functions/v2/https");
const {onDocumentCreated}=require("firebase-functions/v2/firestore");
const admin=require("firebase-admin");admin.initializeApp();
const db=admin.firestore(),auth=admin.auth(),CEO="r4908994@gmail.com",CMO="sarthakxxu@gmail.com";
function assertCEO(r){if(!r.auth||r.auth.token.email!==CEO)throw new HttpsError("permission-denied","CEO access required.");}
exports.approveUser=onCall(async r=>{assertCEO(r);const {uid,xpsId}=r.data||{};if(!uid||!xpsId)throw new HttpsError("invalid-argument","uid and xpsId required");const id=String(xpsId).trim().toUpperCase();if(!/^[A-Z0-9._-]{3,32}$/.test(id))throw new HttpsError("invalid-argument","Invalid XPS ID");const reg=db.collection("xpsRegistry").doc(id),u=db.collection("users").doc(uid);await db.runTransaction(async tx=>{const [a,b]=await Promise.all([tx.get(reg),tx.get(u)]);if(!b.exists)throw new HttpsError("not-found","User not found");if(a.exists&&a.data().uid!==uid)throw new HttpsError("already-exists","XPS ID already assigned");tx.set(reg,{uid,assignedAt:admin.firestore.FieldValue.serverTimestamp()},{merge:true});tx.update(u,{xpsId:id,approvalStatus:"approved",verified:true,approvedBy:CEO,approvedAt:admin.firestore.FieldValue.serverTimestamp(),updatedAt:admin.firestore.FieldValue.serverTimestamp()})});return{ok:true}});
exports.rejectUser=onCall(async r=>{assertCEO(r);const uid=r.data?.uid;if(!uid)throw new HttpsError("invalid-argument","uid required");try{await auth.deleteUser(uid)}catch(e){if(e.code!=="auth/user-not-found")throw e}await db.collection("users").doc(uid).delete();return{ok:true}});
exports.setCMO=onCall(async r=>{assertCEO(r);const uid=r.data?.uid;if(!uid)throw new HttpsError("invalid-argument","uid required");const u=await auth.getUser(uid);if((u.email||"").toLowerCase()!==CMO)throw new HttpsError("failed-precondition","Only the configured CMO email can receive this role.");await db.collection("users").doc(uid).set({role:"admin",designation:"CMO"},{merge:true});return{ok:true}});
exports.purgeUnapprovedAccounts=onSchedule("every 1 hours",async()=>{const cutoff=admin.firestore.Timestamp.fromMillis(Date.now()-86400000);const s=await db.collection("users").where("approvalStatus","==","pending").where("createdAt","<=",cutoff).limit(100).get();for(const d of s.docs){try{await auth.deleteUser(d.id)}catch(e){if(e.code!=="auth/user-not-found")continue}await d.ref.delete()}return null});
exports.syncCMORole=onDocumentCreated("users/{uid}",async e=>{const d=e.data?.data();if(d&&(d.email||"").toLowerCase()===CMO)await e.data.ref.set({role:"admin",designation:"CMO"},{merge:true})});

exports.notifyGrazeSubmission=onDocumentCreated("graze/{grazeId}",async e=>{
  const g=e.data?.data();
  if(!g) return null;
  const now=admin.firestore.FieldValue.serverTimestamp();
  const batch=db.batch();
  for(const email of [CEO,CMO]){
    const snap=await db.collection("users").where("email","==",email).limit(1).get();
    if(!snap.empty){
      const ref=db.collection("notifications").doc();
      batch.set(ref,{uid:snap.docs[0].id,title:"New Graze submission",body:`@${g.ownerUsername||"crew"} submitted a sky observation for review.`,icon:"✦",link:"view:admin",read:false,createdAt:now,createdBy:"system"});
    }
  }
  await batch.commit();
  return null;
});


exports.notifyDirectMessage=onDocumentCreated("directChats/{chatId}/messages/{messageId}",async e=>{
  const m=e.data?.data(); if(!m) return null;
  const chatId=e.params.chatId;
  const chat=await db.collection("directChats").doc(chatId).get(); if(!chat.exists) return null;
  const participants=chat.data().participants||[];
  const recipient=participants.find(uid=>uid!==m.senderUid); if(!recipient) return null;
  await db.collection("notifications").add({uid:recipient,title:"New XPACE message",body:`${m.senderName||"Crew Member"} sent you a message.`,icon:"◫",link:"view:chat",read:false,createdAt:admin.firestore.FieldValue.serverTimestamp(),createdBy:"system"});
  return null;
});
